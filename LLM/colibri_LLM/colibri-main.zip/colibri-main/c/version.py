"""Single source of truth for the colibri version number."""

__version__ = "1.1.1"
